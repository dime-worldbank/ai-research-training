* Clean Data.do
* Cleans the raw baseline/follow-up survey extract for the Table 1 reconstruction example.

import delimited "data/raw_survey_data.csv", clear varnames(1)

* Standardize inconsistent group labels (e.g. " control ", "TREATMENT")
replace treatment_group = strtrim(treatment_group)
replace treatment_group = strproper(treatment_group)

* add value labels 
label def treat 1 "Treatment" 0 "Control"

encode treatment_group, gen(treatment) label(treat)

* check for duplicates
duplicates tag participant_id, gen(dup)
* br if dup ==1 //after checking all the values are the same
* drop the first value 
duplicates drop participant_id, force

* Baseline measures must be complete; follow-up measures may be missing due
* to attrition (participants who could not be reached for the follow-up
* survey), so they are not required here.
drop if missing(baseline_test_score, baseline_savings)

* save cleaned data
drop dup treatment_group 
order participant_id treatment
isid participant_id, sort

save "data/cleaned.dta", replace

