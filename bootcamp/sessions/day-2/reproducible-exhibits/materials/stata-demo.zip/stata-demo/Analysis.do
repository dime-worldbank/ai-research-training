* Analysis.do
*
* Rough first pass at a baseline-vs-follow-up comparison (Table 1). Mirrors
* how the table was originally put together: loop over each variable and
* period, test/display group differences, and list a plain results matrix.
* Nothing here is exported -- the displayed matrices are what a human
* copied into the paper by hand as "Table 1".

use "data/cleaned.dta", clear

local vars baseline_test_score followup_test_score baseline_savings followup_savings

foreach var of local vars {
	display "Variable: `var'"

	sdtest `var', by(treatment)
	local pval = r(p)

	* Decide equal vs. unequal variance t-test based on the sdtest p-value
	if `pval' <= 0.05 {
		ttest `var', by(treatment) unequal
	}
	else {
		ttest `var', by(treatment)
	}
	display " "
}

* Crude table commands -- build a matrix row per variable and list it, the
* same way the old code appended matrix rows and displayed them.
foreach var of local vars {
	 summarize `var' if treatment == 1
	matrix row_t = (r(N), r(mean), r(sd))
	 summarize `var' if treatment == 0
	matrix row_c = (r(N), r(mean), r(sd))
	matrix this_row = (row_t, row_c)
	matrix rownames this_row = `var'
	matrix colnames this_row = N_treat mean_treat sd_treat N_control mean_control sd_control
	matrix list this_row
}
