# Clean the irrigation monitoring data and update the Excel figure.
#
# Usage: Rscript 01-clean-data.R [input.csv] [output.xlsx]
#
# Reads the raw district-level CSV, aggregates it to one row per year, and
# writes the result into the "Clean data" sheet of the output workbook. The
# chart on the "Figure 1" sheet reads from that sheet, so it updates (including
# extra or fewer years) the next time the workbook is opened in Excel.

library(dplyr)
library(readr)
library(stringr)
library(openxlsx)

# --- File paths (can be overridden from the command line) --------------------

args <- commandArgs(trailingOnly = TRUE)

input_file <- if (length(args) >= 1) {
  args[[1]]
} else {
  file.path("data", "synthetic-irrigation-monitoring.csv")
}

output_file <- if (length(args) >= 2) {
  args[[2]]
} else {
  file.path("output", "manual-figure.xlsx")
}

# --- Clean the raw data -------------------------------------------------------

raw_data <- read_csv(input_file, show_col_types = FALSE)

district_data <- raw_data |>
  mutate(
    # Years come in mixed formats ("FY2018", "2019", "FY 2023"); keep the number.
    year = parse_number(year_raw),
    # Tidy inconsistent district names (" north ", "SOUTH" -> "North", "South").
    district = str_to_title(str_trim(district_raw)),
    counted_farms = no_irrigation_farms +
      partial_irrigation_farms +
      full_irrigation_farms
  ) |>
  # Keep only complete records whose farm counts add up to the survey total.
  filter(
    data_complete == 1,
    !is.na(year),
    counted_farms == surveyed_farms
  )

# --- Aggregate to one row per year --------------------------------------------

clean_data <- district_data |>
  group_by(year) |>
  summarise(
    no_irrigation_farms = sum(no_irrigation_farms),
    partial_irrigation_farms = sum(partial_irrigation_farms),
    full_irrigation_farms = sum(full_irrigation_farms),
    # Yield is weighted by farms surveyed. This must come before
    # surveyed_farms is summed, so the weights are still per district.
    mean_yield_kg_ha = weighted.mean(mean_yield_kg_ha, surveyed_farms),
    surveyed_farms = sum(surveyed_farms),
    .groups = "drop"
  ) |>
  mutate(
    # Share of surveyed farms in each irrigation category (sums to 1).
    no_irrigation_share = no_irrigation_farms / surveyed_farms,
    partial_irrigation_share = partial_irrigation_farms / surveyed_farms,
    full_irrigation_share = full_irrigation_farms / surveyed_farms,
    # The irrigation program started in 2021.
    program_active = year >= 2021
  ) |>
  # Columns in the order the "Clean data" sheet expects (A to F).
  select(
    year,
    no_irrigation_share,
    partial_irrigation_share,
    full_irrigation_share,
    mean_yield_kg_ha,
    program_active
  ) |>
  arrange(year)

# --- Write to the Excel workbook ----------------------------------------------

# Open the existing workbook, so the chart and its formatting are kept.
wb <- loadWorkbook(output_file)

# Clear the old data rows, keeping the header row in row 1.
deleteData(wb, "Clean data", cols = 1:6, rows = 2:1000, gridExpand = TRUE)

# Write the new data under the header. The chart uses named ranges
# (Formulas > Name Manager) that count the years in column A, so it picks
# up however many rows are written here.
writeData(wb, "Clean data", clean_data, startRow = 2, colNames = FALSE)

saveWorkbook(wb, output_file, overwrite = TRUE)

message("Wrote clean plotting data to: ", output_file)
