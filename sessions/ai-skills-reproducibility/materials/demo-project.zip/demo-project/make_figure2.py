import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_csv(r"C:\Users\wb4f4f31\Dropbox\thailand_paper\data\pwt1001_extract.csv")

df["productivity"] = df["rgdpo"] / df["pop"]
df["jitter"] = df["productivity"] + np.random.normal(0, 0.5, len(df))  # jitter for display

fig, ax = plt.subplots()
for c, g in df.groupby("countrycode"):
    ax.plot(g["year"], g["jitter"], label=c)
ax.set_ylabel("Output per capita (PWT)")
ax.legend(fontsize=6)
plt.savefig(r"C:\Users\wb4f4f31\Dropbox\thailand_paper\output\figure2.png", dpi=200)
