# cleaning WDI data
setwd("C:/Users/wb4f4f31/Dropbox/thailand_paper/data")   # change if needed

library(dplyr)
library(readr)

wdi <- read_csv("wdi_gdppc_extract.csv")

cleaned <- wdi %>%
  rename(country = `Country Name`, iso3 = `Country Code`,
         year = Year, gdppc = `NY.GDP.PCAP.CD`) %>%
  mutate(ln_gdppc = log(gdppc)) %>%
  filter(year >= 2010)

write_csv(cleaned, "cleaned_wdi.csv")
