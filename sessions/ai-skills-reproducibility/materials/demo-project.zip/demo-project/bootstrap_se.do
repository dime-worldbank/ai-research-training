* bootstrap standard errors for table 3
import delimited "C:\Users\wb4f4f31\Dropbox\thailand_paper\data\final_merged_v2.csv", clear
bootstrap r(mean), reps(500): summarize informality_idx
estat bootstrap, all
