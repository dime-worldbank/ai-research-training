* main analysis  (v3 - FINAL, use this one!!)
cd "C:\Users\wb4f4f31\Dropbox\thailand_paper"

import delimited "data\cleaned_wdi.csv", clear
tempfile wdi
save `wdi'

import delimited "data\final_merged_v2.csv", clear
rename yr year
merge 1:1 iso3 year using `wdi', keep(3) nogen

* keep latest obs per country for table 1
sort iso3


* merge in self employment
tempfile latest
save `latest'
import delimited "data\oecd_self_employment.csv", clear
rename (location time self_emp_pct) (iso3 year selfemp)
merge 1:1 iso3 year using `latest', keep(2 3) nogen

* regressions
reghdfe ln_gdppc informality_idx urban_sh, absorb(iso3) vce(robust)
outreg2 using "output\table2.doc", replace

* figure 1
twoway scatter ln_gdppc informality_idx, mlabel(iso3)
graph export "output\figure1.png", replace
