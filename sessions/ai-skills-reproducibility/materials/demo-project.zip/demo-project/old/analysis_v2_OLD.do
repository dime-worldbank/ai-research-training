* OLD VERSION - do not use
* (kept just in case)
display "old version"
